﻿

namespace BE
{
    public enum Vehicle
    {
        privateCar = 1, motorcycle, midTrailer, maxTrailer
    }
    public enum Gear
    {
        manual = 1, auto
    }
    public enum Gender
    {
        male, female
    }

    public enum User
    {
        administrator = 1,tester,trainee, exit
    }
}